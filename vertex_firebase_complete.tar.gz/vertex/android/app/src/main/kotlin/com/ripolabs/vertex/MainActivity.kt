package com.ripolabs.vertex

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
